package com.araz.scanner;

import android.content.*;import android.graphics.*;import android.graphics.pdf.PdfRenderer;import android.net.Uri;import android.os.Bundle;import android.os.ParcelFileDescriptor;import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;

public class PdfViewerActivity extends AppCompatActivity{
    private ImageView image;private TextView txt;private Uri uri;private ParcelFileDescriptor fd;private PdfRenderer renderer;private int index=0;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_pdf_viewer);image=findViewById(R.id.imgPdf);txt=findViewById(R.id.txtPage);uri=Uri.parse(getIntent().getStringExtra("uri"));
        findViewById(R.id.btnBack).setOnClickListener(v->finish());findViewById(R.id.btnPrev).setOnClickListener(v->{if(index>0){index--;render();}});findViewById(R.id.btnNext).setOnClickListener(v->{if(renderer!=null&&index+1<renderer.getPageCount()){index++;render();}});findViewById(R.id.btnShare).setOnClickListener(v->share());open();}
    private void open(){try{fd=getContentResolver().openFileDescriptor(uri,"r");if(fd==null)throw new IOException("PDF tidak dapat dibuka");renderer=new PdfRenderer(fd);render();}catch(Exception e){Toast.makeText(this,"PDF gagal dibuka: "+e.getMessage(),Toast.LENGTH_LONG).show();finish();}}
    private void render(){if(renderer==null||renderer.getPageCount()==0)return;PdfRenderer.Page p=renderer.openPage(index);int w=1200,h=Math.max(1,(int)(w*(p.getHeight()/(float)p.getWidth())));Bitmap bm=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);bm.eraseColor(Color.WHITE);p.render(bm,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);p.close();image.setImageBitmap(bm);txt.setText((index+1)+" / "+renderer.getPageCount());findViewById(R.id.btnPrev).setEnabled(index>0);findViewById(R.id.btnNext).setEnabled(index+1<renderer.getPageCount());}
    private void share(){Intent s=new Intent(Intent.ACTION_SEND);s.setType("application/pdf");s.putExtra(Intent.EXTRA_STREAM,uri);s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(s,"Share PDF"));}
    @Override protected void onDestroy(){super.onDestroy();try{if(renderer!=null)renderer.close();}catch(Exception ignored){}try{if(fd!=null)fd.close();}catch(Exception ignored){}}
}
