package com.araz.scanner;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;

public class EditorActivity extends AppCompatActivity{
    private DocumentCropView crop;private View controls;private boolean fullscreen=false;private int editIndex=-1;
    private static final int REQ_ENHANCE=77;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_editor);crop=findViewById(R.id.cropView);controls=findViewById(R.id.editorControls);editIndex=getIntent().getIntExtra("edit_index",-1);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        findViewById(R.id.btnLeft).setOnClickListener(v->{Bitmap bm=crop.getBitmap();if(bm!=null)crop.setBitmap(BitmapUtils.rotateLeft(bm));});
        findViewById(R.id.btnRight).setOnClickListener(v->{Bitmap bm=crop.getBitmap();if(bm!=null)crop.setBitmap(BitmapUtils.rotate90(bm));});
        findViewById(R.id.btnAll).setOnClickListener(v->crop.allCorners());
        findViewById(R.id.btnAuto).setOnClickListener(v->{crop.autoDetect();Toast.makeText(this,"Sudut dideteksi ulang",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.btnFullscreen).setOnClickListener(v->toggleFullscreen());
        findViewById(R.id.btnNext).setOnClickListener(v->nextEnhance());load();
    }

    private void load(){
        try{
            Uri uri=Uri.parse(getIntent().getStringExtra("uri"));Bitmap bm;
            if("file".equals(uri.getScheme())){bm=android.graphics.BitmapFactory.decodeFile(uri.getPath());if(bm==null)throw new Exception("Gambar tidak terbaca");}
            else bm=BitmapUtils.loadBitmap(this,uri,3000);
            if(Math.max(bm.getWidth(),bm.getHeight())>3000){float s=3000f/Math.max(bm.getWidth(),bm.getHeight());bm=Bitmap.createScaledBitmap(bm,Math.round(bm.getWidth()*s),Math.round(bm.getHeight()*s),true);}
            crop.setBitmap(bm);
        }catch(Exception e){Toast.makeText(this,"Gagal membuka gambar: "+e.getMessage(),Toast.LENGTH_LONG).show();finish();}
    }

    private void nextEnhance(){
        Bitmap src=crop.getBitmap();PointF[] pts=crop.getPoints();if(src==null||pts==null)return;
        try{
            Bitmap warped=BitmapUtils.perspectiveCrop(src,pts);
            File temp=new File(getCacheDir(),"enhance_"+System.currentTimeMillis()+".jpg");BitmapUtils.saveJpeg(temp,warped,97);
            Intent i=new Intent(this,EnhanceActivity.class);i.putExtra("path",temp.getAbsolutePath());i.putExtra("edit_index",editIndex);startActivityForResult(i,REQ_ENHANCE);
        }catch(Exception e){Toast.makeText(this,"Warp gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==REQ_ENHANCE&&result==RESULT_OK){setResult(RESULT_OK);finish();}}

    private void toggleFullscreen(){fullscreen=!fullscreen;controls.setVisibility(fullscreen?View.GONE:View.VISIBLE);getWindow().getDecorView().setSystemUiVisibility(fullscreen?(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION):0);}
}
