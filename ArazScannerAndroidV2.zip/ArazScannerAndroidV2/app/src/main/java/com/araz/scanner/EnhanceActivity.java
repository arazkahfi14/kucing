package com.araz.scanner;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;

public class EnhanceActivity extends AppCompatActivity{
    private ImageView preview;private Bitmap original,current;private String mode="Original";private int editIndex=-1;private String sourcePath;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_enhance);preview=findViewById(R.id.imgPreview);sourcePath=getIntent().getStringExtra("path");editIndex=getIntent().getIntExtra("edit_index",-1);
        original=BitmapFactory.decodeFile(sourcePath);if(original==null){Toast.makeText(this,"Gambar enhance gagal dibuka",Toast.LENGTH_LONG).show();finish();return;}current=original.copy(Bitmap.Config.ARGB_8888,true);preview.setImageBitmap(current);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        bind(R.id.fOriginal,"Original");bind(R.id.fLighten,"Lighten");bind(R.id.fClean,"Magic Color");bind(R.id.fShadow,"No Shadow");bind(R.id.fBw,"B&W");bind(R.id.fGray,"Grayscale");
        findViewById(R.id.btnRotate).setOnClickListener(v->{original=BitmapUtils.rotate90(original);apply(mode);});
        findViewById(R.id.btnCompare).setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){preview.setImageBitmap(original);return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){preview.setImageBitmap(current);return true;}return false;});
        findViewById(R.id.btnDone).setOnClickListener(v->save());
    }

    private void bind(int id,String m){findViewById(id).setOnClickListener(v->apply(m));}
    private void apply(String m){mode=m;new Thread(()->{Bitmap result=BitmapUtils.applyFilter(original,m);runOnUiThread(()->{current=result;preview.setImageBitmap(current);});}).start();}

    private void save(){
        findViewById(R.id.btnDone).setEnabled(false);
        new Thread(()->{
            try{
                ScanSession s=new ScanSession(this);File out=s.newPageFile();BitmapUtils.saveJpeg(out,current,96);
                if(editIndex>=0)s.replace(editIndex,out.getAbsolutePath());else s.add(out.getAbsolutePath());
                new File(sourcePath).delete();runOnUiThread(()->{setResult(RESULT_OK);finish();});
            }catch(Exception e){runOnUiThread(()->{findViewById(R.id.btnDone).setEnabled(true);Toast.makeText(this,"Gagal simpan: "+e.getMessage(),Toast.LENGTH_LONG).show();});}
        }).start();
    }
}
