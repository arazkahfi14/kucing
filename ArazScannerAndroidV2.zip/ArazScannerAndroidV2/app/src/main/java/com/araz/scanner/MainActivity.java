package com.araz.scanner;

import android.Manifest;import android.content.*;import android.net.Uri;import android.os.Bundle;import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;import androidx.activity.result.contract.ActivityResultContracts;import androidx.appcompat.app.AlertDialog;import androidx.appcompat.app.AppCompatActivity;import androidx.core.content.ContextCompat;import androidx.recyclerview.widget.LinearLayoutManager;
import java.io.File;import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements PageAdapter.Listener{
    private ScanSession session;private PageAdapter adapter;private TextView txtCount;
    private final ActivityResultLauncher<String> pickImage=registerForActivityResult(new ActivityResultContracts.GetContent(),uri->{if(uri!=null)openEditor(uri.toString(),-1);});
    private final ActivityResultLauncher<String> pickPdf=registerForActivityResult(new ActivityResultContracts.GetContent(),uri->{if(uri!=null)openPdf(uri);});
    private final ActivityResultLauncher<Intent> editorLauncher=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->refresh());
    private final ActivityResultLauncher<Intent> cameraLauncher=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->{if(r.getResultCode()==RESULT_OK&&r.getData()!=null){String u=r.getData().getStringExtra("uri");if(u!=null)openEditor(u,-1);}});
    private final ActivityResultLauncher<String> cameraPermission=registerForActivityResult(new ActivityResultContracts.RequestPermission(),g->{if(g)launchCamera();else Toast.makeText(this,"Izin kamera diperlukan",Toast.LENGTH_LONG).show();});

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);setContentView(R.layout.activity_main);session=new ScanSession(this);txtCount=findViewById(R.id.txtCount);adapter=new PageAdapter(this);
        androidx.recyclerview.widget.RecyclerView rv=findViewById(R.id.recyclerPages);rv.setLayoutManager(new LinearLayoutManager(this));rv.setAdapter(adapter);
        findViewById(R.id.btnCamera).setOnClickListener(v->startCamera());findViewById(R.id.btnGallery).setOnClickListener(v->pickImage.launch("image/*"));findViewById(R.id.btnOpenPdf).setOnClickListener(v->pickPdf.launch("application/pdf"));
        findViewById(R.id.btnAbout).setOnClickListener(v->startActivity(new Intent(this,AboutActivity.class)));findViewById(R.id.btnClear).setOnClickListener(v->clearConfirm());
        findViewById(R.id.btnExportPdf).setOnClickListener(v->exportPdf());findViewById(R.id.btnExportJpg).setOnClickListener(v->exportJpg());refresh();
    }
    @Override protected void onResume(){super.onResume();if(session!=null)refresh();}
    private void startCamera(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==android.content.pm.PackageManager.PERMISSION_GRANTED)launchCamera();else cameraPermission.launch(Manifest.permission.CAMERA);}
    private void launchCamera(){cameraLauncher.launch(new Intent(this,CameraActivity.class));}
    private void openEditor(String uri,int idx){Intent i=new Intent(this,EditorActivity.class);i.putExtra("uri",uri);i.putExtra("edit_index",idx);editorLauncher.launch(i);}
    private void openPdf(Uri uri){Intent i=new Intent(this,PdfViewerActivity.class);i.putExtra("uri",uri.toString());i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}
    private void refresh(){ArrayList<String> p=session.getPages();adapter.setPages(p);txtCount.setText(p.isEmpty()?"Belum ada halaman":p.size()+" halaman • tap gambar untuk viewer");}
    private void clearConfirm(){if(session.getPages().isEmpty())return;new AlertDialog.Builder(this).setTitle("Kosongkan scan?").setMessage("Semua halaman sesi ini akan dihapus. File export tetap aman.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{session.clear();refresh();}).show();}

    private void exportPdf(){ArrayList<String> p=session.getPages();if(p.isEmpty()){Toast.makeText(this,"Belum ada halaman",Toast.LENGTH_SHORT).show();return;}new Thread(()->{try{Uri u=ExportUtils.exportPdf(this,p);runOnUiThread(()->{Toast.makeText(this,"PDF berhasil dibuat",Toast.LENGTH_SHORT).show();openPdf(u);});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Gagal PDF: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    private void exportJpg(){ArrayList<String> p=session.getPages();if(p.isEmpty()){Toast.makeText(this,"Belum ada halaman",Toast.LENGTH_SHORT).show();return;}new Thread(()->{try{int n=ExportUtils.exportJpgs(this,p);runOnUiThread(()->Toast.makeText(this,n+" JPG tersimpan",Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Gagal JPG: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}

    @Override public void onOpen(int p){Intent i=new Intent(this,DocumentViewerActivity.class);i.putExtra("index",p);startActivity(i);}
    @Override public void onEdit(int p){openEditor(Uri.fromFile(new File(session.getPages().get(p))).toString(),p);}
    @Override public void onDelete(int p){session.delete(p);refresh();}
    @Override public void onMove(int a,int b){session.move(a,b);refresh();}
}
