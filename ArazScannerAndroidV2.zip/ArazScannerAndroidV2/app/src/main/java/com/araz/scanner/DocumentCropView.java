package com.araz.scanner;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class DocumentCropView extends View{
    private Bitmap bitmap;private PointF[] points;
    private final Paint imagePaint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final Paint linePaint=new Paint(Paint.ANTI_ALIAS_FLAG),handlePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix imageMatrix=new Matrix(),inverse=new Matrix();private int active=-1;

    public DocumentCropView(Context c){super(c);init();}public DocumentCropView(Context c,AttributeSet a){super(c,a);init();}
    private void init(){linePaint.setColor(Color.rgb(82,226,202));linePaint.setStyle(Paint.Style.STROKE);linePaint.setStrokeWidth(5f);handlePaint.setColor(Color.WHITE);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setBitmap(Bitmap b){bitmap=b;points=DocumentDetector.detect(b);requestLayout();invalidate();}
    public Bitmap getBitmap(){return bitmap;}
    public PointF[] getPoints(){if(points==null)return null;PointF[] c=new PointF[4];for(int i=0;i<4;i++)c[i]=new PointF(points[i].x,points[i].y);return c;}
    public void autoDetect(){if(bitmap!=null){points=DocumentDetector.detect(bitmap);invalidate();}}
    public void resetCorners(){if(bitmap!=null){points=DocumentDetector.fallback(bitmap.getWidth(),bitmap.getHeight());invalidate();}}
    public void allCorners(){if(bitmap!=null){points=DocumentDetector.fullFrame(bitmap.getWidth(),bitmap.getHeight());invalidate();}}

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);if(bitmap==null)return;computeMatrix();canvas.drawBitmap(bitmap,imageMatrix,imagePaint);if(points==null)return;
        float[] v=new float[8];for(int i=0;i<4;i++){v[i*2]=points[i].x;v[i*2+1]=points[i].y;}imageMatrix.mapPoints(v);
        Path p=new Path();p.moveTo(v[0],v[1]);p.lineTo(v[2],v[3]);p.lineTo(v[4],v[5]);p.lineTo(v[6],v[7]);p.close();canvas.drawPath(p,linePaint);
        for(int i=0;i<4;i++){canvas.drawCircle(v[i*2],v[i*2+1],18f,handlePaint);canvas.drawCircle(v[i*2],v[i*2+1],12f,linePaint);}
        for(int side=0;side<4;side++){int a=side,b=(side+1)%4;float mx=(v[a*2]+v[b*2])/2f,my=(v[a*2+1]+v[b*2+1])/2f;RectF r=new RectF(mx-28,my-12,mx+28,my+12);canvas.drawRoundRect(r,10,10,handlePaint);}
    }

    private void computeMatrix(){float sx=getWidth()/(float)bitmap.getWidth(),sy=getHeight()/(float)bitmap.getHeight(),s=Math.min(sx,sy);float dx=(getWidth()-bitmap.getWidth()*s)/2f,dy=(getHeight()-bitmap.getHeight()*s)/2f;imageMatrix.reset();imageMatrix.postScale(s,s);imageMatrix.postTranslate(dx,dy);imageMatrix.invert(inverse);}

    @Override public boolean onTouchEvent(MotionEvent e){
        if(points==null||bitmap==null)return false;computeMatrix();float[] pt={e.getX(),e.getY()};inverse.mapPoints(pt);float scale=Math.max(.001f,imageMatrix.mapRadius(1f)),hit=52f/scale;
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            active=-1;for(int i=0;i<4;i++)if(Math.hypot(points[i].x-pt[0],points[i].y-pt[1])<hit){active=i;break;}
            if(active<0){for(int s=0;s<4;s++){int a=s,b=(s+1)%4;float mx=(points[a].x+points[b].x)/2f,my=(points[a].y+points[b].y)/2f;if(Math.hypot(mx-pt[0],my-pt[1])<hit){active=4+s;break;}}}
            return active>=0;
        }else if(e.getAction()==MotionEvent.ACTION_MOVE&&active>=0){
            if(active<4){points[active].x=clamp(pt[0],0,bitmap.getWidth());points[active].y=clamp(pt[1],0,bitmap.getHeight());}
            else{
                int s=active-4,a=s,b=(s+1)%4;float mx=(points[a].x+points[b].x)/2f,my=(points[a].y+points[b].y)/2f;float dx=pt[0]-mx,dy=pt[1]-my;
                points[a].x=clamp(points[a].x+dx,0,bitmap.getWidth());points[a].y=clamp(points[a].y+dy,0,bitmap.getHeight());
                points[b].x=clamp(points[b].x+dx,0,bitmap.getWidth());points[b].y=clamp(points[b].y+dy,0,bitmap.getHeight());
            }
            invalidate();return true;
        }else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){active=-1;return true;}return false;
    }
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
}
