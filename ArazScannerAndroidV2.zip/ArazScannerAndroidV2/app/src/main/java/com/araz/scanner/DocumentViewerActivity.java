package com.araz.scanner;

import android.content.*;import android.graphics.BitmapFactory;import android.net.Uri;import android.os.Bundle;import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;import androidx.core.content.FileProvider;
import java.io.File;import java.util.ArrayList;

public class DocumentViewerActivity extends AppCompatActivity{
    private ImageView image;private TextView pageNo;private int index=0;private ScanSession session;private ArrayList<String> pages;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_document_viewer);image=findViewById(R.id.imgPage);pageNo=findViewById(R.id.txtPageNo);session=new ScanSession(this);index=getIntent().getIntExtra("index",0);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());findViewById(R.id.btnPrev).setOnClickListener(v->{if(index>0){index--;show();}});findViewById(R.id.btnNext).setOnClickListener(v->{if(index+1<pages.size()){index++;show();}});
        findViewById(R.id.btnEdit).setOnClickListener(v->edit());findViewById(R.id.btnShare).setOnClickListener(v->share());show();}
    @Override protected void onResume(){super.onResume();show();}
    private void show(){pages=session.getPages();if(pages.isEmpty()){finish();return;}index=Math.max(0,Math.min(index,pages.size()-1));image.setImageBitmap(BitmapFactory.decodeFile(pages.get(index)));pageNo.setText((index+1)+"/"+pages.size());findViewById(R.id.btnPrev).setEnabled(index>0);findViewById(R.id.btnNext).setEnabled(index+1<pages.size());}
    private void edit(){File f=new File(pages.get(index));Intent i=new Intent(this,EditorActivity.class);i.putExtra("uri",Uri.fromFile(f).toString());i.putExtra("edit_index",index);startActivity(i);}
    private void share(){try{File f=new File(pages.get(index));Uri u=FileProvider.getUriForFile(this,getPackageName()+".files",f);Intent s=new Intent(Intent.ACTION_SEND);s.setType("image/jpeg");s.putExtra(Intent.EXTRA_STREAM,u);s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(s,"Share scan"));}catch(Exception e){Toast.makeText(this,"Share gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
}
