# Araz Scanner V2 — Scan and Go

Native Android document scanner, local/offline.

## V2
- Branding resmi Araz Scanner dengan logo pengguna.
- Home baru: Scan, Import Image, Open PDF.
- Crop editor fullscreen.
- Auto document corners via OpenCV.
- 4 corner handles + 4 side handles yang bisa digeser.
- Rotate Left / Right, All, Auto.
- Crop -> Enhance flow.
- Enhance/filter horizontal: Original, Lighten, Magic Color, No Shadow, B&W, Grayscale.
- Compare before/after dengan tekan-tahan tombol Compare.
- Multi-page session.
- Tap thumbnail untuk membuka viewer internal.
- Edit dan share halaman dari viewer.
- Export PDF robust (anti 0 byte), setelah export langsung terbuka di PDF Viewer internal.
- Buka PDF existing dari HP langsung di viewer internal.
- Export JPG.
- About: dibuat oleh Araz Kahfi.
- Tidak ada model AI tambahan/download engine.

## Roadmap setelah V2 stabil
- Batch capture + auto capture.
- Markup: signature, text, brush, watermark.
- OCR offline / Extract Text.
- Merge/split/reorder PDF lebih lengkap.
