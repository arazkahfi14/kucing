package com.araz.scanner;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class DocumentCropView extends View {
    private Bitmap bitmap; private PointF[] points; private int active=-1;
    private final Paint imagePaint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private final Paint linePaint=new Paint(Paint.ANTI_ALIAS_FLAG); private final Paint handlePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix=new Matrix(), inverse=new Matrix();
    public DocumentCropView(Context c){super(c);init();} public DocumentCropView(Context c,AttributeSet a){super(c,a);init();}
    public DocumentCropView(Context c,AttributeSet a,int s){super(c,a,s);init();}
    private void init(){ linePaint.setColor(Color.rgb(139,92,246)); linePaint.setStyle(Paint.Style.STROKE); linePaint.setStrokeWidth(5f); handlePaint.setColor(Color.WHITE); }
    public void setBitmap(Bitmap b){bitmap=b;points=DocumentDetector.detect(b);invalidate();}
    public Bitmap getBitmap(){return bitmap;}
    public PointF[] getPoints(){ if(points==null)return null; PointF[] c=new PointF[4]; for(int i=0;i<4;i++)c[i]=new PointF(points[i].x,points[i].y); return c; }
    public void autoDetect(){if(bitmap!=null){points=DocumentDetector.detect(bitmap);invalidate();}}
    public void resetCorners(){if(bitmap!=null){points=DocumentDetector.fallback(bitmap.getWidth(),bitmap.getHeight());invalidate();}}
    private void compute(){ if(bitmap==null)return; float s=Math.min(getWidth()/(float)bitmap.getWidth(),getHeight()/(float)bitmap.getHeight()); float dx=(getWidth()-bitmap.getWidth()*s)/2f,dy=(getHeight()-bitmap.getHeight()*s)/2f; matrix.reset();matrix.postScale(s,s);matrix.postTranslate(dx,dy);matrix.invert(inverse); }
    @Override protected void onDraw(Canvas c){ super.onDraw(c); if(bitmap==null)return; compute(); c.drawBitmap(bitmap,matrix,imagePaint); if(points==null)return; float[] v=new float[8]; for(int i=0;i<4;i++){v[i*2]=points[i].x;v[i*2+1]=points[i].y;} matrix.mapPoints(v); Path p=new Path();p.moveTo(v[0],v[1]);p.lineTo(v[2],v[3]);p.lineTo(v[4],v[5]);p.lineTo(v[6],v[7]);p.close();c.drawPath(p,linePaint); Paint num=new Paint(Paint.ANTI_ALIAS_FLAG);num.setColor(Color.rgb(139,92,246));num.setTextSize(24f);num.setTextAlign(Paint.Align.CENTER); for(int i=0;i<4;i++){c.drawCircle(v[i*2],v[i*2+1],24f,handlePaint);c.drawText(String.valueOf(i+1),v[i*2],v[i*2+1]+8,num);} }
    @Override public boolean onTouchEvent(MotionEvent e){ if(points==null||bitmap==null)return false; compute(); float[] pt={e.getX(),e.getY()}; inverse.mapPoints(pt); float hit=48f/Math.max(.001f,matrix.mapRadius(1f)); if(e.getAction()==MotionEvent.ACTION_DOWN){active=-1;for(int i=0;i<4;i++)if(Math.hypot(points[i].x-pt[0],points[i].y-pt[1])<hit){active=i;break;}return active>=0;} if(e.getAction()==MotionEvent.ACTION_MOVE&&active>=0){points[active].x=Math.max(0,Math.min(bitmap.getWidth(),pt[0]));points[active].y=Math.max(0,Math.min(bitmap.getHeight(),pt[1]));invalidate();return true;} if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){active=-1;return true;}return false; }
}
