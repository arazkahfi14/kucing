package com.araz.scanner;

import android.content.Context;
import org.json.JSONArray;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class ScanSession {
    private final File dir,index; private final ArrayList<String> pages=new ArrayList<>();
    public ScanSession(Context c){dir=new File(c.getFilesDir(),"scan_session");dir.mkdirs();index=new File(dir,"pages.json");load();}
    private void load(){pages.clear();if(!index.exists())return;try{String s=new String(java.nio.file.Files.readAllBytes(index.toPath()),StandardCharsets.UTF_8);JSONArray a=new JSONArray(s);for(int i=0;i<a.length();i++){String p=a.getString(i);if(new File(p).exists())pages.add(p);}}catch(Exception ignored){}}
    private void save(){try(FileOutputStream out=new FileOutputStream(index)){out.write(new JSONArray(pages).toString().getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}}
    public ArrayList<String> getPages(){return new ArrayList<>(pages);} public void add(String p){pages.add(p);save();}
    public void replace(int i,String p){if(i<0||i>=pages.size())return;String old=pages.set(i,p);if(!old.equals(p))new File(old).delete();save();}
    public void delete(int i){if(i<0||i>=pages.size())return;new File(pages.remove(i)).delete();save();}
    public void move(int from,int to){if(from<0||from>=pages.size()||to<0||to>=pages.size())return;String p=pages.remove(from);pages.add(to,p);save();}
    public void clear(){for(String p:pages)new File(p).delete();pages.clear();save();}
    public File newPageFile(){return new File(dir,"page_"+System.currentTimeMillis()+".jpg");}
}
