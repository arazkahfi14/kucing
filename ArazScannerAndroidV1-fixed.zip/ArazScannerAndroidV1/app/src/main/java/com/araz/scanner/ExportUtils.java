package com.araz.scanner;

import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class ExportUtils {
    private ExportUtils(){} private static String stamp(){return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());}
    public static Uri exportPdf(Context c,ArrayList<String> pages)throws IOException{
        ContentValues cv=new ContentValues();cv.put(MediaStore.MediaColumns.DISPLAY_NAME,"ArazScanner_"+stamp()+".pdf");cv.put(MediaStore.MediaColumns.MIME_TYPE,"application/pdf");if(Build.VERSION.SDK_INT>=29)cv.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/ArazScanner");
        Uri uri=c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);if(uri==null)throw new IOException("Tidak dapat membuat PDF");PdfDocument pdf=new PdfDocument();
        try{int n=1;for(String path:pages){Bitmap bm=BitmapFactory.decodeFile(path);if(bm==null)continue;int pw=bm.getWidth()>bm.getHeight()?842:595,ph=bm.getWidth()>bm.getHeight()?595:842;PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(pw,ph,n++).create();PdfDocument.Page p=pdf.startPage(info);Canvas can=p.getCanvas();can.drawColor(Color.WHITE);float s=Math.min((pw-40f)/bm.getWidth(),(ph-40f)/bm.getHeight()),w=bm.getWidth()*s,h=bm.getHeight()*s;RectF dst=new RectF((pw-w)/2f,(ph-h)/2f,(pw+w)/2f,(ph+h)/2f);can.drawBitmap(bm,null,dst,new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));pdf.finishPage(p);bm.recycle();}try(OutputStream out=c.getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("Output PDF gagal");pdf.writeTo(out);}}
        catch(Exception e){c.getContentResolver().delete(uri,null,null);if(e instanceof IOException)throw(IOException)e;throw new IOException(e);}finally{pdf.close();}return uri;
    }
    public static int exportJpgs(Context c,ArrayList<String> pages)throws IOException{int n=0,i=1;String folder="Pictures/ArazScanner/"+stamp();for(String path:pages){Bitmap bm=BitmapFactory.decodeFile(path);if(bm==null)continue;ContentValues cv=new ContentValues();cv.put(MediaStore.Images.Media.DISPLAY_NAME,String.format(Locale.US,"scan_%02d.jpg",i++));cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");if(Build.VERSION.SDK_INT>=29)cv.put(MediaStore.Images.Media.RELATIVE_PATH,folder);Uri u=c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);if(u!=null)try(OutputStream out=c.getContentResolver().openOutputStream(u)){if(out!=null&&bm.compress(Bitmap.CompressFormat.JPEG,96,out))n++;}bm.recycle();}return n;}
}
