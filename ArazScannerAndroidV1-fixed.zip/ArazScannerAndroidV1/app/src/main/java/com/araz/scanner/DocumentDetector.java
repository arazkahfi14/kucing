package com.araz.scanner;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PointF;
import java.util.*;

public final class DocumentDetector {
    private DocumentDetector(){}
    public static PointF[] detect(Bitmap src){
        int sw=src.getWidth(), sh=src.getHeight(), max=700;
        float scale=Math.min(1f,max/(float)Math.max(sw,sh));
        int w=Math.max(80,Math.round(sw*scale)), h=Math.max(80,Math.round(sh*scale));
        Bitmap b=scale<1f?Bitmap.createScaledBitmap(src,w,h,true):src;
        int[] px=new int[w*h]; b.getPixels(px,0,w,0,0,w,h); int[] g=new int[w*h];
        for(int i=0;i<px.length;i++){ int c=px[i]; g[i]=(Color.red(c)*299+Color.green(c)*587+Color.blue(c)*114)/1000; }
        int[] mag=new int[w*h]; ArrayList<Integer> sample=new ArrayList<>();
        for(int y=1;y<h-1;y++) for(int x=1;x<w-1;x++){
            int i=y*w+x;
            int gx=-g[i-w-1]-2*g[i-1]-g[i+w-1]+g[i-w+1]+2*g[i+1]+g[i+w+1];
            int gy=-g[i-w-1]-2*g[i-w]-g[i-w+1]+g[i+w-1]+2*g[i+w]+g[i+w+1];
            int m=Math.abs(gx)+Math.abs(gy); mag[i]=m; if(((x+y)&3)==0) sample.add(m);
        }
        if(sample.isEmpty()) return fallback(sw,sh); Collections.sort(sample); int th=sample.get((int)(sample.size()*0.90));
        float minS=Float.MAX_VALUE,maxS=-1,minD=Float.MAX_VALUE,maxD=-Float.MAX_VALUE; PointF tl=null,tr=null,br=null,bl=null;
        int mx=Math.max(2,w/100), my=Math.max(2,h/100);
        for(int y=my;y<h-my;y++) for(int x=mx;x<w-mx;x++) if(mag[y*w+x]>=th){
            float s=x+y,d=x-y; if(s<minS){minS=s;tl=new PointF(x,y);} if(s>maxS){maxS=s;br=new PointF(x,y);} if(d>maxD){maxD=d;tr=new PointF(x,y);} if(d<minD){minD=d;bl=new PointF(x,y);} }
        if(tl==null||tr==null||br==null||bl==null) return fallback(sw,sh);
        PointF[] q={tl,tr,br,bl}; if(Math.abs(area(q))<w*h*.20f) return fallback(sw,sh);
        float inv=1f/scale; return new PointF[]{new PointF(tl.x*inv,tl.y*inv),new PointF(tr.x*inv,tr.y*inv),new PointF(br.x*inv,br.y*inv),new PointF(bl.x*inv,bl.y*inv)};
    }
    private static float area(PointF[] p){ float a=0; for(int i=0;i<4;i++){PointF q=p[(i+1)%4]; a+=p[i].x*q.y-q.x*p[i].y;} return a/2f; }
    public static PointF[] fallback(int w,int h){ float m=Math.min(w,h)*.055f; return new PointF[]{new PointF(m,m),new PointF(w-m,m),new PointF(w-m,h-m),new PointF(m,h-m)}; }
}
