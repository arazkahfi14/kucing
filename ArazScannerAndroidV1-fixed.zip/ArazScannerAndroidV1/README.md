# Araz Scanner Android V1

Scanner dokumen native Android yang berjalan lokal/offline.

## Fitur V1
- Scan kamera dengan CameraX.
- Import foto dari galeri.
- Auto deteksi area dokumen setelah foto diambil.
- Empat titik sudut bisa digeser manual.
- Fullscreen editor agar dokumen mudah dilihat.
- Perspective correction / meluruskan dokumen miring.
- Filter: Warna Asli, Clean Document, Grayscale, Hitam Putih.
- Multi-page session.
- Urutkan halaman naik/turun, edit ulang, dan hapus.
- Export PDF ke Download/ArazScanner.
- Export JPG ke Pictures/ArazScanner.
- Tidak membutuhkan server, akun, atau model AI besar.
- About App: dibuat oleh Araz Kahfi.

## Catatan auto detect
V1 memakai deteksi tepi lokal ringan supaya APK tetap kecil dan tidak membutuhkan model tambahan. Pada latar yang ramai auto detect bisa meleset; empat sudut bisa langsung digeser manual.

## Build
Upload `ArazScannerAndroidV1.zip` dan workflow `build-araz-scanner-v1.yml` ke GitHub. Jalankan workflow manual. Artifact `ArazScanner-APK-V1` berisi `app-debug.apk`.
