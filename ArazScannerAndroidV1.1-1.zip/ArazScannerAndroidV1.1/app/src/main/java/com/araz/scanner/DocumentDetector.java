package com.araz.scanner;

import android.graphics.Bitmap;
import android.graphics.PointF;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.*;
import org.opencv.imgproc.Imgproc;

import java.util.*;

public final class DocumentDetector {
    private DocumentDetector(){}

    public static PointF[] detect(Bitmap src) {
        if (src == null) return null;
        try {
            if (!OpenCVLoader.initLocal()) {
                return fallback(src.getWidth(), src.getHeight());
            }
            return detectOpenCv(src);
        } catch (Throwable ignored) {
            return fallback(src.getWidth(), src.getHeight());
        }
    }

    private static PointF[] detectOpenCv(Bitmap src) {
        int sw = src.getWidth(), sh = src.getHeight();
        int maxDim = 900;
        float scale = Math.min(1f, maxDim / (float)Math.max(sw, sh));
        int w = Math.max(100, Math.round(sw * scale));
        int h = Math.max(100, Math.round(sh * scale));

        Bitmap small = scale < 0.999f
                ? Bitmap.createScaledBitmap(src, w, h, true)
                : src.copy(Bitmap.Config.ARGB_8888, false);

        Mat rgba = new Mat();
        Mat gray = new Mat();
        Mat blurred = new Mat();
        Mat edges = new Mat();
        Mat hierarchy = new Mat();
        Mat kernel = new Mat();
        List<MatOfPoint> contours = new ArrayList<>();

        try {
            Utils.bitmapToMat(small, rgba);
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);
            Imgproc.GaussianBlur(gray, blurred, new Size(5,5), 0);

            // Two-stage edge map works better for white documents on busy backgrounds.
            Imgproc.Canny(blurred, edges, 45, 145);
            kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(5,5));
            Imgproc.morphologyEx(edges, edges, Imgproc.MORPH_CLOSE, kernel, new Point(-1,-1), 2);

            Imgproc.findContours(edges, contours, hierarchy,
                    Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);

            double imageArea = w * (double) h;
            PointF[] best = null;
            double bestScore = -1;

            contours.sort((a,b) -> Double.compare(
                    Math.abs(Imgproc.contourArea(b)),
                    Math.abs(Imgproc.contourArea(a))));

            int checked = 0;
            for (MatOfPoint contour : contours) {
                if (checked++ > 60) break;
                double area = Math.abs(Imgproc.contourArea(contour));
                if (area < imageArea * 0.12 || area > imageArea * 0.96) continue;

                MatOfPoint2f c2 = new MatOfPoint2f(contour.toArray());
                double peri = Imgproc.arcLength(c2, true);

                for (double eps : new double[]{0.012, 0.018, 0.025, 0.035, 0.05}) {
                    MatOfPoint2f approx = new MatOfPoint2f();
                    Imgproc.approxPolyDP(c2, approx, eps * peri, true);
                    Point[] pts = approx.toArray();
                    if (pts.length == 4) {
                        MatOfPoint asInt = new MatOfPoint(pts);
                        if (!Imgproc.isContourConvex(asInt)) {
                            asInt.release(); approx.release(); continue;
                        }

                        PointF[] ordered = order(pts);
                        double polygonArea = Math.abs(area(ordered));
                        if (polygonArea < imageArea * 0.12) {
                            asInt.release(); approx.release(); continue;
                        }

                        int borderTouches = 0;
                        double bx = w * 0.018, by = h * 0.018;
                        for (PointF p : ordered) {
                            if (p.x <= bx || p.y <= by || p.x >= w-bx || p.y >= h-by) borderTouches++;
                        }

                        // Strongly penalize the outer photo/screen border.
                        double score = polygonArea;
                        if (borderTouches >= 3) score *= 0.08;
                        else if (borderTouches == 2) score *= 0.45;
                        else if (borderTouches == 1) score *= 0.80;

                        double rectangularity = polygonArea / Math.max(1.0, area);
                        if (rectangularity > 0.72 && rectangularity < 1.28) score *= 1.15;

                        if (score > bestScore) {
                            bestScore = score;
                            best = ordered;
                        }
                        asInt.release();
                    }
                    approx.release();
                }
                c2.release();
            }

            if (best == null) {
                // Secondary fallback: largest non-border rotated rectangle.
                for (MatOfPoint contour : contours) {
                    double a = Math.abs(Imgproc.contourArea(contour));
                    if (a < imageArea * 0.15 || a > imageArea * 0.90) continue;
                    MatOfPoint2f c2 = new MatOfPoint2f(contour.toArray());
                    RotatedRect rr = Imgproc.minAreaRect(c2);
                    Point[] box = new Point[4];
                    rr.points(box);
                    PointF[] candidate = order(box);
                    int touches = 0;
                    for (PointF p : candidate) {
                        if (p.x < w*.02 || p.y < h*.02 || p.x > w*.98 || p.y > h*.98) touches++;
                    }
                    c2.release();
                    if (touches < 3) {
                        best = candidate;
                        break;
                    }
                }
            }

            if (best == null) return fallback(sw, sh);

            float inv = 1f / scale;
            for (PointF p : best) {
                p.x = clamp(p.x * inv, 0, sw);
                p.y = clamp(p.y * inv, 0, sh);
            }
            return best;
        } finally {
            for (MatOfPoint c : contours) c.release();
            rgba.release(); gray.release(); blurred.release();
            edges.release(); hierarchy.release(); kernel.release();
            if (small != src && !small.isRecycled()) small.recycle();
        }
    }

    private static PointF[] order(Point[] p) {
        Point tl=null,tr=null,br=null,bl=null;
        double minSum=Double.MAX_VALUE,maxSum=-Double.MAX_VALUE;
        double minDiff=Double.MAX_VALUE,maxDiff=-Double.MAX_VALUE;
        for (Point q : p) {
            double sum=q.x+q.y, diff=q.x-q.y;
            if (sum<minSum){minSum=sum;tl=q;}
            if (sum>maxSum){maxSum=sum;br=q;}
            if (diff>maxDiff){maxDiff=diff;tr=q;}
            if (diff<minDiff){minDiff=diff;bl=q;}
        }
        return new PointF[]{
            new PointF((float)tl.x,(float)tl.y),
            new PointF((float)tr.x,(float)tr.y),
            new PointF((float)br.x,(float)br.y),
            new PointF((float)bl.x,(float)bl.y)
        };
    }

    private static double area(PointF[] p) {
        double a=0;
        for(int i=0;i<4;i++){
            PointF q=p[(i+1)%4];
            a += p[i].x*q.y - q.x*p[i].y;
        }
        return a/2.0;
    }

    private static float clamp(float v,float lo,float hi){ return Math.max(lo,Math.min(hi,v)); }

    public static PointF[] fullFrame(int w,int h){
        return new PointF[]{
            new PointF(0,0), new PointF(w-1,0),
            new PointF(w-1,h-1), new PointF(0,h-1)
        };
    }

    public static PointF[] fallback(int w,int h){
        float mx=w*.08f, my=h*.08f;
        return new PointF[]{
            new PointF(mx,my),new PointF(w-mx,my),
            new PointF(w-mx,h-my),new PointF(mx,h-my)
        };
    }
}
