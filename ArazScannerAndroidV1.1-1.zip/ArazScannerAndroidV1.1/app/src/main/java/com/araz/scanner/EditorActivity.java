package com.araz.scanner;

import android.graphics.Bitmap;
import android.graphics.PointF;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;

public class EditorActivity extends AppCompatActivity{
    private DocumentCropView crop;
    private View controls;
    private Spinner spinner;
    private boolean fullscreen=false;
    private int editIndex=-1;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_editor);
        crop=findViewById(R.id.cropView);
        controls=findViewById(R.id.editorControls);
        spinner=findViewById(R.id.spinnerFilter);
        editIndex=getIntent().getIntExtra("edit_index",-1);

        String[] filters={"Warna Asli","Clean Document","Grayscale","Hitam Putih"};
        ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,filters){
            @Override public View getView(int p,View v,android.view.ViewGroup g){
                TextView t=(TextView)super.getView(p,v,g);
                t.setTextColor(android.graphics.Color.WHITE);
                return t;
            }
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup g){
                TextView t=(TextView)super.getDropDownView(p,v,g);
                t.setTextColor(android.graphics.Color.WHITE);
                t.setBackgroundColor(android.graphics.Color.rgb(35,38,45));
                t.setPadding(18,18,18,18);
                return t;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(ad);

        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        findViewById(R.id.btnAuto).setOnClickListener(v->{
            crop.autoDetect();
            Toast.makeText(this,"Sudut dokumen dideteksi ulang",Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnReset).setOnClickListener(v->crop.resetCorners());
        findViewById(R.id.btnRotate).setOnClickListener(v->rotate());
        findViewById(R.id.btnWarp).setOnClickListener(v->warpDocument());
        findViewById(R.id.btnFullscreen).setOnClickListener(v->toggleFullscreen());
        findViewById(R.id.btnSavePage).setOnClickListener(v->save());
        load();
    }

    private void load(){
        try{
            Uri uri=Uri.parse(getIntent().getStringExtra("uri"));
            Bitmap bm;
            if("file".equals(uri.getScheme())){
                bm=android.graphics.BitmapFactory.decodeFile(uri.getPath());
                if(bm==null)throw new Exception("Gambar tidak terbaca");
                if(Math.max(bm.getWidth(),bm.getHeight())>3000){
                    float s=3000f/Math.max(bm.getWidth(),bm.getHeight());
                    bm=Bitmap.createScaledBitmap(bm,Math.round(bm.getWidth()*s),Math.round(bm.getHeight()*s),true);
                }
            }else{
                bm=BitmapUtils.loadBitmap(this,uri,3000);
            }
            crop.setBitmap(bm);
        }catch(Exception e){
            Toast.makeText(this,"Gagal membuka gambar: "+e.getMessage(),Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void rotate(){
        Bitmap b=crop.getBitmap();
        if(b!=null)crop.setBitmap(BitmapUtils.rotate90(b));
    }

    private void warpDocument(){
        Bitmap src=crop.getBitmap();
        PointF[] pts=crop.getPoints();
        if(src==null||pts==null)return;
        try{
            Bitmap warped=BitmapUtils.perspectiveCrop(src,pts);
            if(warped==null||warped.getWidth()<100||warped.getHeight()<100){
                Toast.makeText(this,"Area dokumen terlalu kecil",Toast.LENGTH_SHORT).show();
                return;
            }
            crop.setWarpedBitmap(warped);
            Toast.makeText(this,"Dokumen sudah diluruskan. Cek hasil lalu Simpan.",Toast.LENGTH_SHORT).show();
        }catch(Exception e){
            Toast.makeText(this,"Warp gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void toggleFullscreen(){
        fullscreen=!fullscreen;
        controls.setVisibility(fullscreen?View.GONE:View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(fullscreen?
                (View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION):0);
    }

    private void save(){
        Bitmap src=crop.getBitmap();
        PointF[] pts=crop.getPoints();
        if(src==null||pts==null)return;
        String filter=(String)spinner.getSelectedItem();
        findViewById(R.id.btnSavePage).setEnabled(false);

        new Thread(()->{
            try{
                Bitmap cropped=BitmapUtils.perspectiveCrop(src,pts);
                Bitmap out=BitmapUtils.applyFilter(cropped,filter);
                ScanSession s=new ScanSession(this);
                File f=s.newPageFile();
                BitmapUtils.saveJpeg(f,out,96);
                if(!f.exists()||f.length()==0) throw new Exception("JPG hasil kosong");
                if(editIndex>=0)s.replace(editIndex,f.getAbsolutePath());
                else s.add(f.getAbsolutePath());

                runOnUiThread(()->{
                    setResult(RESULT_OK);
                    finish();
                });
            }catch(Exception e){
                runOnUiThread(()->{
                    findViewById(R.id.btnSavePage).setEnabled(true);
                    Toast.makeText(this,"Gagal simpan: "+e.getMessage(),Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
}
