package com.araz.scanner;

import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class ExportUtils {
    private ExportUtils(){}

    private static String stamp(){
        return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
    }

    public static Uri exportPdf(Context c, ArrayList<String> pages) throws IOException {
        if (pages == null || pages.isEmpty()) throw new IOException("Belum ada halaman");

        File temp = new File(c.getCacheDir(), "ArazScanner_" + stamp() + ".pdf");
        PdfDocument pdf = new PdfDocument();
        int writtenPages = 0;

        try {
            int pageNo=1;
            for(String path:pages){
                File imageFile = new File(path);
                if(!imageFile.exists() || imageFile.length()==0) continue;

                Bitmap bm=BitmapFactory.decodeFile(path);
                if(bm==null) continue;

                int pw=bm.getWidth()>bm.getHeight()?842:595;
                int ph=bm.getWidth()>bm.getHeight()?595:842;

                PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(pw,ph,pageNo++).create();
                PdfDocument.Page p=pdf.startPage(info);
                Canvas canvas=p.getCanvas();
                canvas.drawColor(Color.WHITE);

                float s=Math.min((pw-40f)/bm.getWidth(),(ph-40f)/bm.getHeight());
                float w=bm.getWidth()*s,h=bm.getHeight()*s;
                RectF dst=new RectF((pw-w)/2f,(ph-h)/2f,(pw+w)/2f,(ph+h)/2f);
                canvas.drawBitmap(bm,null,dst,new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
                pdf.finishPage(p);
                writtenPages++;
                bm.recycle();
            }

            if(writtenPages==0) throw new IOException("Tidak ada halaman valid untuk PDF");

            try(FileOutputStream fos=new FileOutputStream(temp)){
                pdf.writeTo(fos);
                fos.flush();
                fos.getFD().sync();
            }
        } finally {
            pdf.close();
        }

        if(!temp.exists() || temp.length()<256){
            temp.delete();
            throw new IOException("PDF gagal dibuat (file kosong)");
        }

        String name="ArazScanner_"+stamp()+".pdf";
        ContentValues cv=new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
        cv.put(MediaStore.MediaColumns.MIME_TYPE,"application/pdf");
        if(Build.VERSION.SDK_INT>=29){
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/ArazScanner");
            cv.put(MediaStore.MediaColumns.IS_PENDING,1);
        }

        Uri uri=c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
        if(uri==null){
            temp.delete();
            throw new IOException("Tidak dapat membuat file PDF tujuan");
        }

        try(InputStream in=new BufferedInputStream(new FileInputStream(temp));
            OutputStream out=new BufferedOutputStream(c.getContentResolver().openOutputStream(uri,"w"))){
            if(out==null) throw new IOException("Output PDF gagal dibuka");
            byte[] buffer=new byte[64*1024];
            int n;
            long copied=0;
            while((n=in.read(buffer))!=-1){
                out.write(buffer,0,n);
                copied+=n;
            }
            out.flush();
            if(copied<256) throw new IOException("PDF tujuan 0 byte");
        } catch(Exception e){
            c.getContentResolver().delete(uri,null,null);
            temp.delete();
            if(e instanceof IOException) throw (IOException)e;
            throw new IOException(e);
        }

        if(Build.VERSION.SDK_INT>=29){
            ContentValues done=new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING,0);
            c.getContentResolver().update(uri,done,null,null);
        }

        temp.delete();
        return uri;
    }

    public static int exportJpgs(Context c,ArrayList<String> pages)throws IOException{
        int n=0,i=1;
        String folder="Pictures/ArazScanner/"+stamp();
        for(String path:pages){
            Bitmap bm=BitmapFactory.decodeFile(path);
            if(bm==null)continue;
            ContentValues cv=new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME,String.format(Locale.US,"scan_%02d.jpg",i++));
            cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            if(Build.VERSION.SDK_INT>=29)cv.put(MediaStore.Images.Media.RELATIVE_PATH,folder);
            Uri u=c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);
            if(u!=null)try(OutputStream out=c.getContentResolver().openOutputStream(u,"w")){
                if(out!=null&&bm.compress(Bitmap.CompressFormat.JPEG,96,out)){out.flush();n++;}
            }
            bm.recycle();
        }
        return n;
    }
}
