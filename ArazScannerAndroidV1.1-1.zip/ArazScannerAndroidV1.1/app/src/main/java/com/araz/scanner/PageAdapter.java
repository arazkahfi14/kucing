package com.araz.scanner;

import android.graphics.BitmapFactory;import android.view.*;import android.widget.*;import androidx.annotation.NonNull;import androidx.recyclerview.widget.RecyclerView;import java.io.File;import java.util.*;
public class PageAdapter extends RecyclerView.Adapter<PageAdapter.VH>{
    public interface Listener{void onEdit(int p);void onDelete(int p);void onMove(int a,int b);}private final ArrayList<String> pages=new ArrayList<>();private final Listener l;public PageAdapter(Listener l){this.l=l;}public void setPages(List<String> p){pages.clear();pages.addAll(p);notifyDataSetChanged();}
    @NonNull public VH onCreateViewHolder(@NonNull ViewGroup p,int v){return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_page,p,false));}
    public void onBindViewHolder(@NonNull VH h,int pos){String path=pages.get(pos);h.page.setText("Halaman "+(pos+1));h.info.setText(BitmapUtils.prettySize(new File(path)));h.thumb.setImageBitmap(BitmapFactory.decodeFile(path));h.up.setEnabled(pos>0);h.down.setEnabled(pos<pages.size()-1);h.up.setOnClickListener(v->l.onMove(h.getBindingAdapterPosition(),h.getBindingAdapterPosition()-1));h.down.setOnClickListener(v->l.onMove(h.getBindingAdapterPosition(),h.getBindingAdapterPosition()+1));h.edit.setOnClickListener(v->l.onEdit(h.getBindingAdapterPosition()));h.del.setOnClickListener(v->l.onDelete(h.getBindingAdapterPosition()));}
    public int getItemCount(){return pages.size();}
    static class VH extends RecyclerView.ViewHolder{ImageView thumb;TextView page,info;Button up,down,edit,del;VH(View v){super(v);thumb=v.findViewById(R.id.imgThumb);page=v.findViewById(R.id.txtPage);info=v.findViewById(R.id.txtInfo);up=v.findViewById(R.id.btnUp);down=v.findViewById(R.id.btnDown);edit=v.findViewById(R.id.btnEdit);del=v.findViewById(R.id.btnDelete);}}
}
