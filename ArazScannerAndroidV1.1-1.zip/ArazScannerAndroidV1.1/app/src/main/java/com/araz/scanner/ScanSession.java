package com.araz.scanner;

import android.content.Context;
import org.json.JSONArray;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ScanSession {
    private final Context context;
    private final File dir;
    private final File index;
    private final ArrayList<String> pages=new ArrayList<>();

    public ScanSession(Context c){
        context=c.getApplicationContext();
        dir=new File(context.getFilesDir(),"scan_session");
        dir.mkdirs();
        index=new File(dir,"pages.json");
        load();
    }

    private synchronized void load(){
        pages.clear();
        if(!index.exists())return;
        try{
            String s=new String(java.nio.file.Files.readAllBytes(index.toPath()), StandardCharsets.UTF_8);
            JSONArray a=new JSONArray(s);
            for(int i=0;i<a.length();i++){
                String p=a.getString(i);
                if(new File(p).exists() && new File(p).length()>0) pages.add(p);
            }
        }catch(Exception ignored){}
    }

    private synchronized void save(){
        try(FileOutputStream fos=new FileOutputStream(index)){
            fos.write(new JSONArray(pages).toString().getBytes(StandardCharsets.UTF_8));
            fos.flush();
            fos.getFD().sync();
        }catch(Exception ignored){}
    }

    public synchronized ArrayList<String> getPages(){
        load();
        return new ArrayList<>(pages);
    }

    public synchronized void add(String path){
        load();
        if(new File(path).exists() && new File(path).length()>0) pages.add(path);
        save();
    }

    public synchronized void replace(int i,String path){
        load();
        if(i<0||i>=pages.size())return;
        String old=pages.set(i,path);
        if(!old.equals(path)) new File(old).delete();
        save();
    }

    public synchronized void delete(int i){
        load();
        if(i<0||i>=pages.size())return;
        new File(pages.remove(i)).delete();
        save();
    }

    public synchronized void move(int from,int to){
        load();
        if(from<0||from>=pages.size()||to<0||to>=pages.size())return;
        String p=pages.remove(from);pages.add(to,p);save();
    }

    public synchronized void clear(){
        load();
        for(String p:pages)new File(p).delete();
        pages.clear();save();
    }

    public File newPageFile(){
        return new File(dir,"page_"+System.currentTimeMillis()+".jpg");
    }
}
