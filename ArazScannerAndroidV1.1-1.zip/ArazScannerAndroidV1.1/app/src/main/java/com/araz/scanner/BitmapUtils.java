package com.araz.scanner;

import android.content.Context;
import android.graphics.*;
import android.net.Uri;
import androidx.exifinterface.media.ExifInterface;
import java.io.*;
import java.util.Locale;

public final class BitmapUtils {
    private BitmapUtils() {}

    public static Bitmap loadBitmap(Context c, Uri uri, int maxDim) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > maxDim * 2) sample *= 2;
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inSampleSize = Math.max(1, sample);
        opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bm;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            bm = BitmapFactory.decodeStream(in, null, opt);
        }
        if (bm == null) throw new IOException("Gambar tidak dapat dibaca");
        bm = rotateFromExif(c, uri, bm);
        if (Math.max(bm.getWidth(), bm.getHeight()) > maxDim) {
            float s = maxDim / (float)Math.max(bm.getWidth(), bm.getHeight());
            bm = Bitmap.createScaledBitmap(bm, Math.round(bm.getWidth()*s), Math.round(bm.getHeight()*s), true);
        }
        return bm;
    }

    private static Bitmap rotateFromExif(Context c, Uri uri, Bitmap bm) {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) return bm;
            ExifInterface exif = new ExifInterface(in);
            int o = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            int deg = 0;
            if (o == ExifInterface.ORIENTATION_ROTATE_90) deg = 90;
            else if (o == ExifInterface.ORIENTATION_ROTATE_180) deg = 180;
            else if (o == ExifInterface.ORIENTATION_ROTATE_270) deg = 270;
            if (deg != 0) {
                Matrix m = new Matrix(); m.postRotate(deg);
                return Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            }
        } catch (Exception ignored) {}
        return bm;
    }

    public static Bitmap rotate90(Bitmap src) {
        Matrix m = new Matrix(); m.postRotate(90);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
    }

    public static Bitmap perspectiveCrop(Bitmap src, PointF[] p) {
        float top = dist(p[0],p[1]), bottom = dist(p[3],p[2]);
        float left = dist(p[0],p[3]), right = dist(p[1],p[2]);
        int w = Math.max(200, Math.round(Math.max(top,bottom)));
        int h = Math.max(200, Math.round(Math.max(left,right)));
        float[] s = {p[0].x,p[0].y,p[1].x,p[1].y,p[2].x,p[2].y,p[3].x,p[3].y};
        float[] d = {0,0,w,0,w,h,0,h};
        Matrix m = new Matrix();
        if (!m.setPolyToPoly(s,0,d,0,4)) return src.copy(Bitmap.Config.ARGB_8888,true);
        Bitmap out = Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out); c.drawColor(Color.WHITE);
        c.drawBitmap(src,m,new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
        return out;
    }
    private static float dist(PointF a, PointF b){ return (float)Math.hypot(a.x-b.x,a.y-b.y); }

    public static Bitmap applyFilter(Bitmap src, String mode) {
        if (mode == null || mode.startsWith("Warna")) return src;
        if (mode.startsWith("Hitam")) return threshold(src);
        Bitmap out = Bitmap.createBitmap(src.getWidth(),src.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        ColorMatrix cm = new ColorMatrix();
        if (mode.startsWith("Grayscale")) cm.setSaturation(0f);
        else {
            float contrast=1.18f, t=(-.5f*contrast+.5f)*255f+8f;
            cm.set(new float[]{contrast,0,0,0,t,0,contrast,0,0,t,0,0,contrast,0,t,0,0,0,1,0});
        }
        p.setColorFilter(new ColorMatrixColorFilter(cm)); c.drawBitmap(src,0,0,p); return out;
    }

    private static Bitmap threshold(Bitmap src) {
        int w=src.getWidth(), h=src.getHeight();
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); int[] row=new int[w];
        long sum=0; int count=0; int sy=Math.max(1,h/200), sx=Math.max(1,w/200);
        for(int y=0;y<h;y+=sy){ src.getPixels(row,0,w,0,y,w,1); for(int x=0;x<w;x+=sx){ int c=row[x]; sum+=(Color.red(c)*299+Color.green(c)*587+Color.blue(c)*114)/1000; count++; }}
        int th=(int)Math.max(115,Math.min(205,(sum/Math.max(1,count))*0.92));
        for(int y=0;y<h;y++){ src.getPixels(row,0,w,0,y,w,1); for(int x=0;x<w;x++){ int c=row[x]; int g=(Color.red(c)*299+Color.green(c)*587+Color.blue(c)*114)/1000; row[x]=g>th?Color.WHITE:Color.BLACK; } out.setPixels(row,0,w,0,y,w,1); }
        return out;
    }

    public static File saveJpeg(File file, Bitmap bm, int quality) throws IOException {
        File parent=file.getParentFile(); if(parent!=null) parent.mkdirs();
        try(FileOutputStream fos=new FileOutputStream(file)){ if(!bm.compress(Bitmap.CompressFormat.JPEG,quality,fos)) throw new IOException("Gagal menyimpan JPG"); }
        return file;
    }
    public static String prettySize(File f){ double kb=f.length()/1024.0; return kb<1024?String.format(Locale.US,"%.0f KB",kb):String.format(Locale.US,"%.1f MB",kb/1024.0); }
}
