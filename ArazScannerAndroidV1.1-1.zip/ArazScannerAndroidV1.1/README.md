# Araz Scanner Android V1.1

Scanner dokumen native Android, lokal/offline.

## Perbaikan V1.1
- Export PDF diperbaiki: PDF dibuat dulu ke file temporary, divalidasi tidak 0 byte, baru disalin ke Download/ArazScanner.
- Sinkronisasi halaman diperbaiki agar halaman hasil editor/kamera langsung terbaca oleh halaman utama.
- Auto Sudut ditingkatkan menggunakan OpenCV contour + quadrilateral detection.
- Deteksi batas foto/screen diberi penalti supaya sistem lebih memilih kontur kertas di dalam foto.
- Tombol **Warp / Luruskan Dokumen** ditambahkan.
- Setelah Warp, hasil perspektif langsung terlihat sebelum disimpan.
- 4 titik sudut tetap bisa digeser manual.
- Fullscreen editor tetap tersedia.
- Filter: Warna Asli, Clean Document, Grayscale, Hitam Putih.
- Multi-page, reorder, edit, hapus, export PDF/JPG tetap tersedia.

## Catatan
V1.1 menambah OpenCV lokal ke APK untuk deteksi dokumen yang lebih stabil. Tidak ada model AI terpisah dan tidak ada download engine setelah install.
