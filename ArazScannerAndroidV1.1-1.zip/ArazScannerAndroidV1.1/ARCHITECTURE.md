# Architecture

CameraX / Gallery
  -> bitmap + EXIF orientation
  -> lightweight document edge detector
  -> draggable 4-corner editor
  -> perspective transform
  -> document filter
  -> local multi-page session
  -> Android PdfDocument / MediaStore

Semua pemrosesan V1 berlangsung lokal di perangkat.
